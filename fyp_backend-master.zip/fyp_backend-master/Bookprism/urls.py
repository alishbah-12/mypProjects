from django.contrib import admin
from django.urls import path,include
from rest_framework.urlpatterns import format_suffix_patterns
from books import views


urlpatterns = [
    path('admin/', admin.site.urls),

    path('book/', views.BookList.as_view()),
    path('book/<int:pk>/', views.BookDetail.as_view()),

    path('category/', views.CategoryList.as_view()),
    path('category/<int:pk>/', views.CategoryDetail.as_view()),

    path('bookimage/', views.BookImageList.as_view()),
    path('bookimage/<int:pk>/', views.BookImageDetail.as_view()),
]
"""path('book/api/', include('books.urls')),"""

urlpatterns=format_suffix_patterns(urlpatterns)