from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

import os
# import the necessary packages
from PIL import Image

import cv2
# speech synthesizer
import pyttsx3
# OCR
import pytesseract
from pytesseract import Output
pytesseract.pytesseract.tesseract_cmd = r'C:\Users\Rohan\AppData\Local\Tesseract-OCR\tesseract.exe'


from Bookprism.settings import FILES_DIR





# Movie Maker
from moviepy.editor import *



# Create your models here.

class Category(models.Model):
    categoryId= models.AutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='categoryId')
    categoryName= models.CharField(max_length=50,blank=False)
    def __str__(self):
        return str(self.categoryName)


class Book(models.Model):
    bookId=models.AutoField(auto_created=True,primary_key=True, serialize=False, verbose_name='bookId')
    name = models.CharField(max_length=50,blank=False)
    videoPath = models.CharField(max_length=100,blank=True)
    coverImagePath = models.CharField(max_length=100, blank=True)
    public = models.BooleanField(default=False)
    rating= models.FloatField(default=0.0, validators=[MinValueValidator(0.0), MaxValueValidator(5.0)])
    totalRate= models.PositiveIntegerField(default=0)
    category=models.ForeignKey(Category,on_delete=models.CASCADE,blank=False)

    def __str__(self):
        return str(self.name)


    def CreateVideo(self):
        if (self.coverImagePath != ""):
            #imageName=os.path.join(PROJECT_ROOT, "static\\books\images\capture.png")
            videopath = str(self.bookId) + ".mp4"
            file_path = os.path.join(FILES_DIR, videopath)
            print(file_path) # its just for Django to store on the specified location
            videopath = "videos/"+videopath # its just for storing in db for react to use
            # load the example image and convert it to grayscale

            image_path=self.coverImagePath
            image = cv2.imread(self.coverImagePath)
            if image is None:
                print("Image Not Loaded")
                return ""
            #cv2.imshow("Image", image)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            gray = cv2.medianBlur(gray, 3)
            # write the grayscale image to disk as a temporary file so we can
            # apply OCR to it
            filename_temp = "{}.png".format(os.getpid())
            cv2.imwrite(filename_temp, gray)

            # load the image as a PIL/Pillow image, apply OCR, and then delete
            # the temporary file
            mytext = pytesseract.image_to_string(Image.open(filename_temp))
            os.remove(filename_temp)

            # replacing next line with space
            mytext = mytext.replace('\n', ' ')

            self.__syncronization(image_path,mytext,file_path)


            return videopath
        return ""


    def __highlightText(self,filename, textLines, index):
        img = cv2.imread(filename)
        d = pytesseract.image_to_data(img, output_type=Output.DICT, lang='eng')
        n_boxes = len(d['level'])

        temptext = textLines[index].split(" ")
        temptext = list(filter(lambda a: a != '', temptext))
        temptext[-1] = temptext[-1] + "."
        # print(temptext)

        img_new = None
        overlay = img.copy()
        for i in range(n_boxes):
            text = d['text'][i]

            if text == temptext[0]:
                (x, y, w, h) = (d['left'][i], d['top'][i], d['width'][i], d['height'][i])
                x1, y1, w1, h1 = (0, 0, 0, 0)
                j = i
                for t in temptext:
                    text = d['text'][j]

                    # print(text)
                    if text == "":
                        # print("Its nothing")
                        j += 1
                        text = d['text'][j]
                        # text=text.replace('.', '')
                        cv2.rectangle(overlay, (x, y), (x1 + w1, y1 + h1), (255, 0, 0), -1)
                        alpha = 0.4  # Transparency factor.
                        # Following line overlays transparent rectangle over the image
                        img_new = cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0)
                        (x, y, w, h) = (d['left'][j], d['top'][j], d['width'][j], d['height'][j])

                    elif text != t:
                        x1, y1, w1, h1 = (x, y, 0, 0)
                        break
                    if text == t:
                        # print("Equal = "+t)
                        (x1, y1, w1, h1) = (d['left'][j], d['top'][j], d['width'][j], d['height'][j])
                    j += 1
                if (x == x1 and y == y1 and w1 == 0 and h1 == 0):
                    continue
                cv2.rectangle(overlay, (x, y), (x1 + w1, y1 + h1), (255, 0, 0), -1)
                alpha = 0.4  # Transparency factor.
                # Following line overlays transparent rectangle over the image
                img_new = cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0)
                """cv2.imshow('Highlighted img', img_new)
                cv2.waitKey(0)
                cv2.destroyAllWindows()"""
                break
        return img_new



    def __syncronization(self,filename, mytext,file_path):

        #filename = 'Capture.PNG'

        textLines = mytext.split(".")
        # index=1
        image_clips = []
        audio_clips = []

        # initialize Text-to-speech engine
        engine = pyttsx3.init()
        # slower
        engine.setProperty("rate", 120)

        for index in range(len(textLines) - 1):
            imageFileName = "junkFiles/"+str(index) + ".JPG"

            new_image = self.__highlightText(filename, textLines, index)
            cv2.imwrite(imageFileName, new_image)

            audioFileName = "junkFiles/"+str(index) + ".mp3"
            engine.save_to_file(textLines[index], audioFileName)
            print(textLines[index])
            engine.runAndWait()
            audio = AudioFileClip(audioFileName)
            audio_clips.append(audio)
            image_clips.append(ImageClip(imageFileName).set_duration(audio.duration))

        video = concatenate(image_clips, method="compose")
        video.audio = concatenate_audioclips(audio_clips)
        video.write_videofile(file_path, fps=1)

        for index in range(len(textLines) - 1):
            audioFileName = "junkFiles/" + str(index) + ".mp3"
            imageFileName = "junkFiles/" + str(index) + ".JPG"
            os.remove(audioFileName)
            os.remove(imageFileName)

        return True







class BookImage(models.Model):
    book=models.ForeignKey(Book,on_delete=models.CASCADE,blank=False)
    imagePath=models.CharField(max_length=100,blank=False)

    def __str__(self):
        return self.imagePath


"""[
      { id: 1, label: "Drama" },
      { id: 2, label: "Fairy Tale" },
      { id: 3, label: "Fiction" },
      { id: 4, label: "Fantasy" },
      { id: 5, label: "Folklore" },
      { id: 6, label: "Tall Tale" },
    ];"""