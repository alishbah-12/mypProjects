from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import Book
from .models import Category
from .models import BookImage

from .serializers import BookSerializer
from .serializers import CategorySerializer
from .serializers import BookImageSerializer




# Create your views here.
class BookList(APIView):
    def get(self, request):
        books= Book.objects.all()
        serializer= BookSerializer(books,many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer= BookSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)


class BookDetail(APIView):
    def get(self,request,pk):
        book= Book.objects.get(pk=pk)
        if(book.videoPath ==""):
            book.videoPath=book.CreateVideo()
            book.save();
        serializer = BookSerializer(book)
        return Response(serializer.data)


    def put(self, request, pk):
        book = Book.objects.get(pk=pk)
        serializer= BookSerializer(book,data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        book=Book.objects.get(pk=pk)
        book.delete()
        return Response(status=status.HTTP_200_OK)



class CategoryList(APIView):
    def get(self, request):
        cat= Category.objects.all()
        serializer= CategorySerializer(cat,many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer= CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)

class CategoryDetail(APIView):
    def get(self,request,pk):
        cat= Category.objects.get(pk=pk)
        serializer = CategorySerializer(cat)
        return Response(serializer.data)


    def put(self, request, pk):
        cat = Category.objects.get(pk=pk)
        serializer= CategorySerializer(cat,data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        cat=Category.objects.get(pk=pk)
        cat.delete()
        return Response(status=status.HTTP_200_OK)




class BookImageList(APIView):
    def get(self, request):
        booksImage= BookImage.objects.all()
        serializer= BookImageSerializer(booksImage,many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer= BookImageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)


class BookImageDetail(APIView):
    def get(self,request,pk):
        bookImage= BookImage.objects.get(pk=pk)
        serializer = BookImageSerializer(bookImage)
        return Response(serializer.data)


    def put(self, request, pk):
        bookImage = BookImage.objects.get(pk=pk)
        serializer= BookImageSerializer(bookImage,data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        bookImage=BookImage.objects.get(pk=pk)
        bookImage.delete()
        return Response(status=status.HTTP_200_OK)
