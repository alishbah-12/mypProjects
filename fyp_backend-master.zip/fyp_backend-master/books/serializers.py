from rest_framework import serializers
from .models import Book
from .models import Category
from .models import BookImage

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model=Book
        fields= '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields ='__all__'

class BookImageSerializer(serializers.ModelSerializer):
    class Meta:
        model=BookImage
        fields ='__all__'
